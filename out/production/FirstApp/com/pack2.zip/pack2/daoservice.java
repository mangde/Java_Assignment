package com.pack2;

public interface daoservice {
    boolean addEmployee(Employee e);
    boolean deleteEmployee(int id);
    boolean searchEmployee(String name);
    boolean displayAllEmployee();
}
