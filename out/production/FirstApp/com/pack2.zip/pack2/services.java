package com.pack2;

public interface services {

   boolean addEmployee(Employee e);
   boolean deleteEmployee(int id);
   boolean displayAllEmployee();
   boolean  searchEmployee(String name);
}
