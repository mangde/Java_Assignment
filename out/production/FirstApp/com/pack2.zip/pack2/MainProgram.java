package com.pack2;

import java.util.ArrayList;
import java.util.Scanner;


public class MainProgram {

    static Scanner sd = new Scanner(System.in);

    public static void main(String[] args) {

        String choice;
        services si = new ServiceImpl();
        Employee tempEmployee = new Employee();


        // statements and prompts within the console for the user to follow
        do {
            System.out.println("Please enter your choice below from the following options");
            System.out.println("View all  employees => 1 ");
            System.out.println("Delete an employee => 2 ");
            System.out.println("Add an employee => 3");
            System.out.println("Search employee=> 4");
            System.out.println("To exit the system = 0 ");

            int tempvar = sd.nextInt();

            switch (tempvar) {
                case 0:
                    System.exit(0);
                    break;

                case 1:
                    if(!si.displayAllEmployee()){
                        System.out.println("Empty Records...");
                    }
                    break;

                case 2:
                    System.out.println("Below are a list of all employees.");
                    System.out.println("Please enter the Employee id of the employee you wish to delete");
                    int tempeid = sd.nextInt();
                    if (si.deleteEmployee(tempeid))
                        System.out.println("You have deleted : " + tempeid);
                    else
                        System.out.println("The Employee Id you have entered is incorrect");

                    break;

                case 3:
                    System.out.println("You have chosen to add an employee to the system");
                    System.out.println("Please enter the EmpId of the new employee: ");
                    int id = sd.nextInt();
                    tempEmployee.setEmpId(id);

                    System.out.println("Please enter the FirstName of the new employee: ");
                    String fname1 = sd.next();
                    tempEmployee.setFname(fname1);

                    System.out.println("Please enter the LastName of the new employee: ");
                    String lname2 = sd.next();
                    tempEmployee.setLname(lname2);

                    System.out.println("Please enter Department name");
                    String department4 = sd.next();
                    tempEmployee.setDepartment(department4);


                    System.out.println("Please enter your Manager name");
                    String manager3 = sd.next();
                    tempEmployee.setManagername(manager3);

                    System.out.println("Please enter the Salary of the new employee: ");
                    double salary5 = sd.nextDouble();
                    tempEmployee.setSalary(salary5);

                    if(si.addEmployee(tempEmployee)){
                        System.out.println("Employee added successfully");

                    }else{
                        System.out.println("Employee Record Not add Employee id already in record");
                    }
                    break;

                case 4:
                    System.out.println("Please enter the Employee FirstName for search");
                    String tempname = sd.next();
                    if (si.searchEmployee(tempname)) {
                        System.out.println("Found Employee Details");
                        System.out.println("Employee Id :" + tempEmployee.getEmpId());
                        System.out.println("Employee FName : " + tempEmployee.getFname());
                        System.out.println("Employee LName : " + tempEmployee.getLname());
                        System.out.println("Employee ManagerName : " + tempEmployee.getManagername());
                        System.out.println("Employee department : " + tempEmployee.getDepartment());
                        System.out.println("Employee Salary : " + tempEmployee.getSalary());

                    } else {
                        System.out.println("Employee record Name Not found");
                    }
                    break;

                    default:
                        System.out.println("Invalid input");
            }


            System.out.println("Do u want to be continue..Y/N");
            choice = sd.next();
        } while (choice != "y");

    }

}