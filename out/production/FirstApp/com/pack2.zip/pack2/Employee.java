package com.pack2;

public class Employee {
    private int EmpId;
    private String Fname;
    private String Lname;
    private String Department;
    private String Managername;
    private double Salary;


    public Employee() {}

    public int getEmpId() {
        return EmpId;
    }

    public void setEmpId(int empId) {
        EmpId = empId;
    }


    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getManagername() {
        return Managername;
    }

    public void setManagername(String managername) {
        Managername = managername;
    }

    public double getSalary() {
        return Salary;
    }

    public void setSalary(double salary) {
        Salary = salary;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }

    //when printing employee list method it sets the input to display as below
    public String toString() {
        return
                "EmpID: " + this.EmpId + " " + "FirstName: " + this.Fname + "  " + "LastName: " + this.Lname + "  "

                        + "Department: " + this.Department + "  " + "ManagerName: " + this.Managername + "  "
                        + "Salary: " + this.Salary;
    }

}
