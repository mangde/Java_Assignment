package com.pack2;

public class ServiceImpl implements services {

    daoservice ds= new DaoServiceImpl();

    public  ServiceImpl(){}

    @Override
    public boolean addEmployee(Employee tempEmployee) {

       if(ds.addEmployee(tempEmployee)) return true;

       return false;
    }

    @Override
    public boolean deleteEmployee(int id) {
        if (ds.deleteEmployee(id))  return true;

        return false;

    }

    @Override
    public boolean displayAllEmployee() {
       if(ds.displayAllEmployee()) return true;

       return false;
    }

    @Override
    public boolean searchEmployee(String tempname) {

        if(ds.searchEmployee(tempname)) return true;

            return false;


    }
}
