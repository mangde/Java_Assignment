package com.pack2;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.stream.*;

public class DaoServiceImpl implements daoservice {

    ArrayList<Employee> list = new ArrayList<Employee>();
    Employee tempEmployee;


    @Override
    public boolean displayAllEmployee() {
        if(list.isEmpty())return false;

        IntStream.range(0, list.size()).mapToObj(i -> list.get(i)).forEach(System.out::println);
        return true;
    }


    @Override
    public boolean addEmployee(Employee e) {
        list.add(e);
        return true;
    }

    @Override
    public boolean deleteEmployee(int id) {

        if (list.isEmpty() == false) {
            int a = 0;
            while (a < list.size()) {
                tempEmployee = list.get(a);
                if (tempEmployee.getEmpId()==id) {
                    list.remove(tempEmployee);
                    return true;
                }
                a++;
            }

        }            return false;


    }


    @Override
    public boolean searchEmployee(String name) {
        if (list.isEmpty() == false) {
            int a = 0;
            while (a < list.size()) {
                tempEmployee = list.get(a);
                if (tempEmployee.getFname().equals(name)) {
                    return true;
                }
                a++;
            }

        }            return false;

    }
}
